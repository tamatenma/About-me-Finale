# about me: the grand finale

A Pen created on CodePen.io. Original URL: [https://codepen.io/skyfeather57/pen/BaJMLJa](https://codepen.io/skyfeather57/pen/BaJMLJa).

